from lumavate_service_util import lumavate_route, SecurityType, RequestType
from flask import render_template, g
from behavior import Service

@lumavate_route('/', ['GET'], RequestType.page, [SecurityType.jwt])
def root():
  return render_template('home.html', logo='/{}/{}/discover/icons/microservice.png'.format(g.integration_cloud, g.widget_type))

@lumavate_route('/drivers', ['get'], RequestType.api, [SecurityType.signed, SecurityType.sut])
def drivers():
  return [x['componentData'] for x in g.service_data.get('drivers', [])]

@lumavate_route('/menu', ['get'], RequestType.api, [SecurityType.signed, SecurityType.sut])
def menu():
  return [x['componentData'] for x in g.service_data.get('menu', [])]

@lumavate_route('/schedule', ['get'], RequestType.api, [SecurityType.signed, SecurityType.sut])
def schedule():
  return [x['componentData'] for x in g.service_data.get('schedule', [])]

@lumavate_route('/all', ['get'], RequestType.api, [SecurityType.signed, SecurityType.sut])
def all():
  return {
    'drivers': [x['componentData'] for x in g.service_data.get('drivers', [])],
    'menu': [x['componentData'] for x in g.service_data.get('menu', [])],
    'schedule': [x['componentData'] for x in g.service_data.get('schedule', [])]
  }

@lumavate_route('/discover/properties', ['GET'], RequestType.system, [SecurityType.jwt])
def properties():
  return Service().do_properties()
