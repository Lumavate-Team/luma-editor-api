from flask import g
from lumavate_service_util import get_lumavate_request, LumavateRequest, SecurityAssertion
from lumavate_properties import Properties, Components
from lumavate_exceptions import ApiException

class Service():
  def do_properties(self, ic='ic', url_ref='ms'):
    c = Properties.ComponentPropertyType

    driver_component_props = [
      Properties.Property(None, 'Driver Data', 'carNumber', 'Car Number', 'text'),
      Properties.Property(None, 'Driver Data', 'firstName', 'First Name', 'text'),
      Properties.Property(None, 'Driver Data', 'lastName', 'Last Name', 'text'),
      Properties.Property(None, 'Driver Data', 'sponsor', 'Sponsor', 'text'),
      Properties.Property(None, 'Driver Data', 'points', 'Points', 'text'),
      Properties.Property(None, 'Driver Data', 'position', 'Position', 'text'),
      Properties.Property(None, 'Driver Data', 'twitterHandle', 'Twitter Handle', 'text'),
      Properties.Property(None, 'Driver Data', 'frequency', 'Frequency', 'text'),
      Properties.Property(None, 'Driver Data', 'country', 'Country', 'text'),
      Properties.Property(None, 'Driver Data', 'engine', 'Engine', 'text'),
      Properties.Property(None, 'Driver Images', 'carImage', 'Car', 'image-upload'),
      Properties.Property(None, 'Driver Images', 'driverImage', 'Driver', 'image-upload'),
    ]

    driver_component = Components.BaseComponent('driver', 'driver', None, 'Driver', None, 'icon-url', driver_component_props, display_name_template = "{{ componentData.carNumber }} - {{ componentData.firstName}} {{ componentData.lastName }}")
    driver_property = Properties.Property('Drivers', 'Driver Settings', 'drivers', 'Drivers', 'components', c.options([driver_component]), [])

    menu_component_props = [
      Properties.Property(None, 'Menu', 'category', 'Category', 'text'),
      Properties.Property(None, 'Menu', 'title', 'Name', 'text'),
      Properties.Property(None, 'Menu', 'description', 'Description', 'text'),
      Properties.Property(None, 'Menu', 'price', 'Price', 'text'),
    ]

    menu_component = Components.BaseComponent('menu', 'menu', None, 'Menu', None, 'icon-url', menu_component_props, display_name_template = "{{ componentData.category }} - {{ componentData.title }}")
    menu_property = Properties.Property('Menu', 'Menu Settings', 'menu', 'Menu', 'components', c.options([menu_component]), [])

    schedule_component_props = [
      Properties.Property(None, 'Schedule', 'date', 'Date', 'text'),
      Properties.Property(None, 'Schedule', 'time', 'Time', 'text'),
      Properties.Property(None, 'Schedule', 'title', 'Title', 'text'),
    ]

    schedule_component = Components.BaseComponent('schedule', 'schedule', None, 'Schedule', None, 'icon-url', schedule_component_props, display_name_template = "{{ componentData.date }} - {{ componentData.time}} - {{ componentData.title }}")
    schedule_property = Properties.Property('Schedule', 'Schedule Settings', 'schedule', 'Schedule', 'components', c.options([schedule_component]), [])

    return [driver_property.to_json(), menu_property.to_json(), schedule_property.to_json()]
